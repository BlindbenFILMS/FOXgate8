# NIKKI JEFFORDS GAMES: merge pack (Blind Canvas Games, New Artists Wing)

Three finished minigames for Nikki Jeffords' paintings, ready to merge into the master AR viewer.
Ben has approved all three. Each one is tested (the bot plays to the finale with no errors at 400×860 phone size),
narrated by Ben's recorded voice, and ends with Nikki's own clip.

| # | Painting (artwork id) | Game | File | Export | Voice prefix |
|---|---|---|---|---|---|
| 16 | Fellowship (`fellowship`) | Pass It On | fellowship-pass.js (+ fellowship-pass-things.js) | `fellowshipPassGame` | `fellow-` |
| 17 | Move the Needle (`move-the-needle`) | Your Voice Moves the Needle | needle-voice.js (+ needle-voice-things.js) | `needleVoiceGame` | `needle-` |
| 18 | Self-Worth: A New Understanding (`self-worth-a-new-understanding`) | Set It Down | selfworth-door.js (+ selfworth-things.js) | `selfWorthDoorGame` | `worth-` |

## What's in this zip
- `AR/lib/minigames/`: the 6 game files (all NEW files; the same copies are already in Ben's AR folder).
- `AR/media/voice/`: 62 recorded mp3s from Ben (fellow-*, needle-*, worth-*). These are NEW and already copied into Ben's AR/media/voice.
- `AR/lib/minigames/new-game-notes/`:
  - one merge note per game (`fellowship.md`, `move-the-needle.md`, `self-worth-a-new-understanding.md`)
  - `NIKKI-voice-lines-to-add.js`: the 62 entries to paste into voice-lines.js
  - `NIKKI-JEFFORDS-VOICE-SCRIPT.txt`: the recording script
- `extras/`: the props sheets (for looking only; nothing to merge).

## The only edits to shared files

### 1. `AR/lib/minigames/index.js`
Add the imports:
```js
import { fellowshipPassGame } from './fellowship-pass.js';
import { needleVoiceGame } from './needle-voice.js';
import { selfWorthDoorGame } from './selfworth-door.js';
```
Add to SPECIAL:
```js
  'fellowship': fellowshipPassGame,                       // Pass It On: tap PASS when the bell rings to pass the glow around the circle
  'move-the-needle': needleVoiceGame,                     // Your Voice Moves the Needle: speak, sing or hum to move the sound wave and the VU needle (Hold to hum if no mic)
  'self-worth-a-new-understanding': selfWorthDoorGame,    // Set It Down: let go of six bundles of old embarrassment and walk through the door
```
Also add these to the comment list at the top of SPECIAL: Fellowship: Pass it on; Move the Needle: Your voice moves the needle; Self-Worth: Set it down.

### 2. `AR/lib/minigames/voice.js`: PREFIX map
```js
  'fellowship': 'fellow-', 'move-the-needle': 'needle-', 'self-worth-a-new-understanding': 'worth-',
```

### 3. `AR/lib/minigames/voice-lines.js`
Paste the 62 entries from `new-game-notes/NIKKI-voice-lines-to-add.js` into the default export.
Every line each game speaks was checked against voice.js plan(): all of them map to Ben's clips, and none fall back to the computer voice.

Nothing else changes. kit.js, artworks.js, the engines and the other games are untouched.

## Retired files: do NOT import
Two earlier drafts that Ben rejected are still in his AR/lib/minigames folder. They can be deleted:
- `fellowship-circle.js`, `fellowship-things.js` (old "Gather the Circle")
- `needle-nudge.js`, `needle-things.js` (old "Just a Little Bit")

## Nikki's own words at the end
Each game plays Nikki's clip after the finale panel. It tries these in order:
1. `3D/gallery/audio/wing_5_0.mp3` (Fellowship), `wing_5_1.mp3` (Needle), `wing_5_2.mp3` (Self-Worth). Please confirm these are hers.
2. Backup: the sound of her statement video `AR/media/clips/<artwork id>.mp4`, which is already in the AR folder.
3. Only if both fail: her quote is read aloud.
Her quote itself is never in Ben's voice.

## Things to know
- **Move the Needle uses the microphone.** It asks when the game starts and stops the mic tracks in stop(). If the mic is denied or missing, HOLD TO HUM and HIGH HUM work instead. The last round records a few seconds of the player's voice and plays it back at the finale.
- **The painting is a sound wave.** Ben's note: Move the Needle is a music painting of an audio wave. Nikki's words are about moving the needle, meaning causing change. The game joins the two: your voice moves the needle.
- **Self-Worth panel opacity.** Self-Worth sets the kit's score panel to opacity 0.999. This avoids a headless-renderer glitch (a gray box behind the buttons, also seen in Embracing Unity in tests). It looks identical. Optional: make the same change in kit.js for every game.
- **Lost painting.** No game switches to a screen view when the painting is lost; they pause, as the viewer expects.
- **Bot mode.** All three support bot mode (&bot=1 or ctx.bot), pause/resume and full cleanup in stop().
