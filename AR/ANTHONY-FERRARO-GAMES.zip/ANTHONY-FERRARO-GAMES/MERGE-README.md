# Anthony Ferraro — three new Blind Canvas Games (for the main chat to merge)
Made 3 Nov 2026. Everything here sits at the same path it goes to in 8GATES-SITE. kit.js was NOT changed.

## The three games
| Painting (work id) | Game | Export | File | Voice prefix |
|---|---|---|---|---|
| One Love (`one-love`) | Light up ONE LOVE | `lightUpOneLoveGame` | onelove-light.js (+ onelove-things.js) | `love-` |
| Light on the Other Side (`light-on-the-other-side`) | Keep rolling | `keepRollingGame` | roll-keep.js (+ roll-things.js) | `roll-` |
| The Button is to the Left (`the-button-is-to-the-left`) | Cross the street | `crossTheStreetGame` | button-cross.js (+ button-things.js) | `button-` |

## Steps to merge
1. Copy `AR/` over the site's `AR/` folder (new files only: 6 game files, 3 notes, the voice script, art in
   `media/games/onelove|roll|button/`, and 62 mp3s in `media/voice/`). Nothing existing is overwritten except notes.
2. `AR/lib/minigames/index.js`: add the import and map lines from each note in `new-game-notes/`
   (one-love.md, light-on-the-other-side.md, the-button-is-to-the-left.md).
3. `AR/lib/minigames/voice.js` PREFIX map: add
   `'one-love': 'love-', 'light-on-the-other-side': 'roll-', 'the-button-is-to-the-left': 'button-',`
4. `AR/lib/minigames/voice-lines.js`: add the entries from `new-game-notes/ANTHONY-voice-lines-to-add.js`.
5. KEEP "Wait." in The Button is to the Left in the COMPUTER voice: it is never recorded and has no button- line.
6. Anthony's own clips: the games read `work.statementAudio` if given, otherwise the gallery files
   (wing_0_2 = One Love, wing_0_1 = Light on the Other Side, wing_0_0 = The Button is to the Left). Keep Rolling
   plays whole sentences from wing_0_1 mid-run and pauses the ride while he speaks.

## Please check in the real viewer / 3D gallery
- On a phone: Keep Rolling's Help bar (64 px from bottom) sits above the viewer's Stop bar with no overlap.
- Finish cards: each game protects its title box with its own style tag, so a host page's `.top` rule can't squash it.

`PREVIEWS/` holds the stand-alone preview pages Ben played (for reference only; they expect the lib/three, kit and
targets folders beside them, like the published previews).
